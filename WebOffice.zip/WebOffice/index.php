<?php
include_once 'init.php';
include_once 'office/template.php';
/* $d = new Domain('192.168.40.201','Admin','');
echo $d->leave(); */