<?php
include_once 'init.php';
include_once 'office/template.php';