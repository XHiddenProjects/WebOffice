$(document).ready(()=>{
    //Prevent users from using inspect element
    //$(document).on("contextmenu",(function(e){e.preventDefault()})),$(document).on("keydown",(function(e){123===e.keyCode&&e.preventDefault(),e.ctrlKey&&e.shiftKey&&73===e.keyCode&&e.preventDefault(),e.ctrlKey&&85===e.keyCode&&e.preventDefault()}));
    AOS.init();
});